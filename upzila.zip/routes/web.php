<?php

use App\Http\Controllers\backend\ProfileController;
use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\HomeController;
use  App\Http\Controllers\backend\SliderController;
use  App\Http\Controllers\backend\ContactController;
use  App\Http\Controllers\backend\OverseerController;
use  App\Http\Controllers\backend\UnionController;
use  App\Http\Controllers\backend\UpazilaController;
use  App\Http\Controllers\Frontend\FrontendController;



// frontend area
Route::get('/', [FrontendController::class, 'index'])->name('welcome');

Route::get('overseers/details/{slug}', [FrontendController::class, 'overseerDetails'])->name('overseer.details');

Auth::routes(['register' => false]);




// backend area
Route::group(['prefix' => 'dashboard'], function (){

    Route::get('/', [HomeController::class, 'index'])->name('/');

    Route::resource('sliders', SliderController::class);
    Route::get('sliders/change-status/{slider}', [SliderController::class, 'changeStatus'])->name('sliders.status');


    Route::resource('contacts', ContactController::class);
    Route::get('contacts/{contact}/change-status', [ContactController::class, 'changeStatus'])->name('contacts.status');


    Route::resource('overseers', OverseerController::class);
    Route::get('overseers/{overseer}/change-status', [OverseerController::class, 'changeStatus'])->name('overseers.status');

    Route::resource('upazilas', UpazilaController::class);
    Route::get('upazilas/{upazila}/change-status', [UpazilaController::class, 'changeStatus'])->name('upazilas.status');

    Route::resource('upazilas.unions', UnionController::class);



    Route::resource('profiles', ProfileController::class)->only(['index', 'update']);

});

