<div class="footer">
    <div>
        <strong> &copy; Copyright {{ date('Y') }} <strong><span>Tax Collection Scheme Ltd. (HTCSL)</span></strong>. All rights reserved | Privacy Policy - REVISED</strong>
    </div>
</div>
