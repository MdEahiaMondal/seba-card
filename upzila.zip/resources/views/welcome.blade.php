<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="{{ asset('frontend') }}/img/favicon.png" rel="icon">
    <link href="{{ asset('frontend') }}/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i,900"
          rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="{{ asset('frontend') }}/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/vendor/venobox/venobox.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/vendor/aos/aos.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="{{ asset('frontend') }}/css/style.css" rel="stylesheet">
    <link href="{{ asset('frontend') }}/css/coustom_style.css" rel="stylesheet">

</head>
<body class="antialiased">
<!-- ======= Top Bar ======= -->

<!-- ======= Header ======= -->
<header id="header">
    <div class="container">

        <div class="logo float-left someInfo">
            <p class="text-light test" id="ddd">
                <span>মোট উপজেলা :- </span><span>{{ $upazilas->count() }}</span> |
                <span>মোট ইউনিয়ন :- </span><span>{{ $unions }}</span>
            </p>
        </div>

        <nav class="nav-menu float-right d-none d-lg-block">
            <ul>
                <li class="active"><a href="{{ route('welcome') }}"><strong>প্রথম পাতা</strong></a></li>
                <li class="drop-down"><a href=""><strong>উপজেলা সমুহ</strong></a>
                    <ul>
                        @foreach($upazilas as $upazila)
                        <li class="{{ $upazila->unions->count() > 0 ? 'drop-down' : '' }}"><a href="#">{{ $upazila->unions->count() > 0 ? '('.$upazila->unions->count().')' : '' }} {{ $upazila->name }}</a>
                            @if($upazila->unions->count() > 0)
                                <ul>
                                    @foreach($upazila->unions as $union)
                                    <li><a target="_blank" href="{{ $union->web_link }}">{{ $union->name }}</a></li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                        @endforeach
                    </ul>
                </li>
                <li>
                    <a href="#team">
                        <strong>গুরুত্বপূর্ণ ব্যক্তি</strong>
                    </a>
                </li>
                <li>
                    <a href="#contact">
                        <strong>যোগাযোগ</strong>
                    </a>
                </li>

            </ul>
        </nav><!-- .nav-menu -->

    </div>
</header><!-- End Header -->


<!-- ======= Hero Section ======= -->
<section  id="hero">
    <div class="hero-container" >
        <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

            <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

            <div class="carousel-inner" role="listbox">
                <!-- Slide 1 -->
                @foreach($sliders as $key=>$slider)
                    <div class="carousel-item {{ $key === 0 ? 'active' : '' }}" style="background-image: url('{{ asset('uploads/sliders/'.$slider->image) }}')">
                        <div class="carousel-container">
                            <div class="carousel-content container">
                                <h2 class="animate__animated animate__fadeInDown">{{ $slider->title }}</h2>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon icofont-rounded-left" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon icofont-rounded-right" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>

        </div>
    </div>
</section><!-- End Hero -->

<!-- ======= Our Team Section ======= -->
<section id="team" class="team">
    <div class="container">
        <div class="section-title">
            <h2>গুরুত্বপূর্ণ ব্যক্তি</h2>
        </div>

        <div class="row justify-content-center">
                        @foreach($overseers as $overseer)
                            <div class="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay="100">
                                <div class="member">
                                    <div class="pic" style="height: 245px;">
                                        <img style="width: 100%; height: 215px"
                                             src="{{ asset('uploads/overseers/'.$overseer->image) }}"
                                             class="img-fluid" alt="">
                                    </div>
                                    <div class="member-info">
                                        <h4>{{ $overseer->name }}</h4>
                                        <span>{{ $overseer->designation }}</span>
                                        <span>{{ $overseer->phone }}</span>
                                        <!-- Button trigger modal -->
                                        <a type="button" onclick="overseerDetails('{{ $overseer->slug }}')"
                                           class="custom_btn">
                                            বিস্তারিত
                                        </a>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
        {{--modal page include--}}
        @include('modal')
    </div>
</section><!-- End Our Team Section -->


<!-- ======= Contact Us Section ======= -->
<section id="contact" class="contact">
    <div class="container">

        <div class="section-title">
            <h2>আমাদের  সাথে যোগাযোগ করুন </h2>
        </div>

        <div class="row">

            <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up">
                <div class="info-box">
                    <i class="bx bx-map"></i>
                    <h3>আমাদের ঠিকানা</h3>
                    <p>{{ @$contact_us->our_address }}</p>
                </div>
            </div>

            <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
                <div class="info-box">
                    <i class="bx bx-envelope"></i>
                    <h3>আমাদেরকে ইমেইল করুন</h3>
                    <p>{{ @$contact_us->email }}</p>
                </div>
            </div>

            <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
                <div class="info-box ">
                    <i class="bx bx-phone-call"></i>
                    <h3>আমাদের কল করুন</h3>
                    <p>{{ @$contact_us->phone }}</p>
                </div>
            </div>
            <div class="col-lg-3 d-flex align-items-stretch" data-aos="fade-up">
                <div class="info-box">
                    <i class="bx bx-face"></i>
                    <h3>আমাদের ফ্যাক্স করুন</h3>
                    <p>{{ @$contact_us->fax }}</p>
                </div>
            </div>
        </div>

    </div>
    </div>
</section><!-- End Contact Us Section -->


<!-- ======= Footer ======= -->
<footer id="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright {{ date('Y') }} <strong><span>Tax Collection Scheme Ltd. (HTCSL)</span></strong>. All rights reserved | Privacy Policy - REVISED
        </div>
       {{-- <div class="credits">
            Develop by <a href="#">HTCSL Develop Team</a>
        </div>--}}
    </div>
</footer><!-- End Footer -->
<!-- Vendor JS Files -->
<script src="{{ asset('frontend') }}/vendor/jquery/jquery.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/php-email-form/validate.js"></script>
<script src="{{ asset('frontend') }}/vendor/jquery-sticky/jquery.sticky.js"></script>
<script src="{{ asset('frontend') }}/vendor/venobox/venobox.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/counterup/counterup.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="{{ asset('frontend') }}/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="{{ asset('frontend') }}/js/main.js"></script>

<script>
    function overseerDetails(slug) {
        $.ajax({
            url: "{{ route('overseer.details', '') }}/" + slug,
            success: function (data) {
                $('#exampleModalCenter').modal('show')
                $(".overseerDetails").html(data)
            }
        })
    }


</script>

</body>
</html>
