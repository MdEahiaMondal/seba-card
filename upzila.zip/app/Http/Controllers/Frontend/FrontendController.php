<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use App\Models\Overseer;
use App\Models\Slider;
use App\Models\Union;
use App\Models\Upazila;
use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index()
    {
        $upazilas = Upazila::active()->with('unions')->get();

        $sliders = Slider::active()->get();

        $unions = Union::all()->count();

        $overseers = Overseer::active()->get();

        $contact_us = $contact = Contact::active()->first();

        return view('welcome', compact('contact_us', 'upazilas', 'sliders', 'unions', 'overseers'));
    }

    public function overseerDetails($slug)
    {
        $overseer = Overseer::where(['slug' => $slug])->where('status', 1)->first();
        return view('frontend.overseers.info', compact('overseer'));
    }
}
