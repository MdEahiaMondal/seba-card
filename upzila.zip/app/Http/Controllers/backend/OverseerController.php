<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\CommonController\CommonController;
use App\Http\Controllers\Controller;
use App\Http\Requests\OverseerRequest;
use App\Models\Overseer;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class OverseerController extends Controller
{

    public function index()
    {

        $overseers = Overseer::latest()->get();
        return view('backend.overseers.index', compact('overseers'));
    }


    public function create()
    {
        return view('backend.overseers.create');
    }


    public function store(OverseerRequest $request)
    {

        $slug = Str::slug($request->name);

        if ($request->hasFile('photo')) {
            $image = $request->file('photo');
            $image_name = CommonController::fileUploaded(
                $slug, false, $image, 'overseers', ['width' => '600', 'height' => '600']
            );
            $request['image'] = $image_name;
        }


        $request['status'] = $request->status ?? 0;
        $request['slug'] = $slug;

        $only = $request->only([
            'name',
            'slug',
            'designation',
            'phone',
            'office_phone',
            'email',
            'batch_no',
            'joining_date',
            'image',
            'office_address',
            'home_address',
            'gender',
            'status',
        ]);

        Overseer::create($only);

        return back()->with('successMsg', 'উপদর্শক সফলভাবে তৈরি করা হয়েছে');


    }


    public function show(Overseer $overseer)
    {
        return view('backend.overseers.show',  compact('overseer'));
    }


    public function edit(Overseer $overseer)
    {
        return view('backend.overseers.edit', compact('overseer'));
    }


    public function update(OverseerRequest $request, Overseer $overseer)
    {
        $slug = Str::slug($request->name);

        if ($request->hasFile('photo')) {
            $image = $request->file('photo');
            $image_name = CommonController::fileUploaded(
                $slug, false, $image, 'overseers', ['width' => '600', 'height' => '600'], $overseer->image
            );
            $request['image'] = $image_name;
        }else{
            $request['image'] = $overseer->image;
        }


        $request['status'] = $request->status ?? 0;
        $request['slug'] = $slug;

        $only = $request->only([
            'name',
            'slug',
            'designation',
            'phone',
            'office_phone',
            'email',
            'batch_no',
            'joining_date',
            'image',
            'office_address',
            'home_address',
            'gender',
            'status',
        ]);

        $overseer->update($only);

        return redirect()->route('overseers.index')->with('successMsg', 'উপদর্শক সফলভাবে কিছুটা রূপান্তর করা হয়েছে');

    }


    public function destroy(Overseer $overseer)
    {
        if ($overseer->image){
            CommonController::deleteImage('overseers', $overseer->image);
        }
        $overseer->delete();
        return redirect()->route('overseers.index')->with('successMsg', 'উপদর্শক সফলভাবে মুছে ফেলা হয়েছে');

    }

    public function changeStatus(Overseer $overseer){

        $overseer->status = !$overseer->status;
        $overseer->save();

        return redirect()->back()->with('successMsg', 'উপদর্শক প্রকাশনার অবস্থা সফলভাবে পরিবর্তন হয়েছে');
    }

}
