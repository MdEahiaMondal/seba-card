<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use App\Models\Upazila;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class UpazilaController extends Controller
{

    public function index()
    {
        $upazilas = Upazila::with('unions')->latest()->get();
        return view('backend.upazilas.index', compact('upazilas'));
    }


    public function create()
    {
        return view('backend.upazilas.create');
    }


    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required'
        ]);

        Upazila::create([
            'name' => $request->name,
            'slug' => Str::slug($request->name),
            'status' => $request->status ?? 0
        ]);

        return redirect()->route('upazilas.index')->with('successMsg', 'উপজেলা সফলভাবে তৈরি হয়েছে');

    }


    public function show(Upazila $upazila)
    {
        //
    }


    public function edit(Upazila $upazila)
    {
        return view('backend.upazilas.edit', compact('upazila'));
    }


    public function update(Request $request, Upazila $upazila)
    {
        $this->validate($request, [
            'name' => 'required'
        ]);

        $upazila->name = $request->name;
        $upazila->slug = Str::slug($request->name);
        $upazila->status = $request->status ?? 0;
        $upazila->save();

        return redirect()->route('upazilas.index')->with('successMsg', 'উপজেলা সফলভাবে আপডেট হয়েছে');
    }


    public function destroy(Upazila $upazila)
    {
        $upazila->delete();
        return redirect()->route('upazilas.index')->with('successMsg', 'উপজেলা সফলভাবে মুছে ফেলা হয়েছে');
    }


    public function changeStatus(Upazila $upazila)
    {

        $upazila->status = !$upazila->status;
        $upazila->save();

        return redirect()->back()->with('successMsg', 'উপজেলা প্রকাশনার অবস্থা সফলভাবে পরিবর্তন হয়েছে');
    }

}
