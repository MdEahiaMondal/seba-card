<?php

namespace App\Http\Controllers\backend;

use App\Http\Requests\UnionRequest;
use App\Models\Union;
use App\Models\Upazila;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Str;

class UnionController extends Controller
{

    public function index(Upazila $upazila)
    {
       return view('backend.unions.index', compact('upazila'));
    }


    public function create(Upazila $upazila)
    {
        return view('backend.unions.create', compact('upazila'));
    }


    public function store(Upazila  $upazila, UnionRequest $request)
    {

        foreach ($request->name as $key=>$value){
            Union::create([
                'name' => $value,
                'slug' => Str::slug($value),
                'web_link' => $request->web_link[$key],
                'upazila_id' => $upazila->id,
            ]);
        }
        return redirect()->route('upazilas.unions.index', $upazila->slug)->with('successMsg', 'ইউনিয়ন সফলভাবে তৈরি করা হয়েছে');

    }


    public function edit(Upazila $upazila, Union $union)
    {
        return view('backend.unions.edit', compact('upazila', 'union'));
    }


    public function update(Upazila $upazila, UnionRequest $request, Union $union)
    {
        $union->update([
            'name' => $request->name[0],
            'slug' => Str::slug($request->name[0]),
            'web_link' => $request->web_link[0],
            'upazila_id' => $upazila->id,
        ]);
        return redirect()->route('upazilas.unions.index', $upazila->slug)->with('successMsg', 'ইউনিয়ন সফলভাবে আপডেট হয়েছে');
    }


    public function destroy(Upazila  $upazila, Union $union)
    {
        $union->delete();
        return redirect()->route('upazilas.unions.index', $upazila->slug)->with('successMsg', 'ইউনিয়ন সফলভাবে মুছে ফেলা হয়েছে');
    }
}
