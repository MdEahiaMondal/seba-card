
<?php $__env->startSection('title', 'কনট্যাক্ট সমূহ'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.html">হোম</a>
                </li>
                <li class="breadcrumb-item">
                    <a>কনট্যাক্ট</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>কনট্যাক্ট সমূহ</strong>
                </li>
            </ol>
            <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-sm btn-primary pull-right m-t-n-md" type="submit"><i
                        class="fa fa-plus"></i> <strong>তৈরি করুন</strong></a>
        </div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox ">
                    <div class="ibox-title">
                        <h5><strong>কনট্যাক্ট সমূহ</strong></h5>
                    </div>
                    <div class="ibox-content">

                        <div class="table-responsive">
                            <table class="table table-hover dataTables-example">
                                <thead>
                                <tr>
                                    <th>নং</th>
                                    <th>আমাদের ঠিকানা</th>
                                    <th>ফোন</th>
                                    <th>ইমেল</th>
                                    <th>ওয়েব</th>
                                    <th>ফ্যাক্স</th>
                                    <th>স্ট্যাটাস</th>
                                    <th>প্রক্রিয়া</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e(Str::limit($contact->our_address, 20)); ?></td>
                                        <td><?php echo e($contact->phone); ?></td>
                                        <td><?php echo e($contact->email); ?></td>
                                        <td><?php echo e($contact->web); ?></td>
                                        <td><?php echo e($contact->fax); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('contacts.status', $contact->slug)); ?>"
                                               title="Change publication status">
                                                <?php if($contact->status == 1): ?>
                                                    <span class="badge badge-primary"><strong>সক্রিয়</strong></span>
                                                <?php else: ?>
                                                    <span class="badge badge-warning"><strong>নিষ্ক্রিয়</strong></span>
                                                <?php endif; ?>
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('contacts.edit', $contact->slug)); ?>" title="Edit"
                                               class="btn btn-info cus_btn">
                                                <i class="fa fa-pencil-square-o"></i> <strong>হালনাগাদ</strong>
                                            </a>

                                            <a onclick="deleteRow(<?php echo e($contact->id); ?>)" href="JavaScript:void(0)"
                                               title="Delete" class="btn btn-danger cus_btn">
                                                <i class="fa fa-trash"></i> <strong>বাদ দিন</strong>
                                            </a>
                                            <form id="row-delete-form<?php echo e($contact->id); ?>" method="POST"
                                                  action="<?php echo e(route('contacts.destroy', $contact->slug)); ?>"
                                                  style="display: none">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\contacts\index.blade.php ENDPATH**/ ?>