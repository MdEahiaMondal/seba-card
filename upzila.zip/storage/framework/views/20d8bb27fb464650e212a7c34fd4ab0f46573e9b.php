<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo e(asset('backend')); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend')); ?>/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo e(asset('backend')); ?>/css/animate.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend')); ?>/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="loginColumns animated fadeInDown">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8 col-xs-12">

            <?php echo $__env->yieldContent('from'); ?>

            <hr>
            <div class="row">
                <div class="col-md-6">
                    Copyright HTCSl Company
                </div>
                <div class="col-md-6 text-right">
                    <small>© <?php echo e(date('Y')); ?></small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Mainly scripts -->
<script src="<?php echo e(asset('backend')); ?>/js/jquery-3.1.1.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/js/popper.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/js/bootstrap.js"></script>

</body>

</html>

<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\auth\layouts\app.blade.php ENDPATH**/ ?>