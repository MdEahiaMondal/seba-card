<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <img alt="image" class="rounded-circle"
                         style="width: 48px; height: 48px"
                         <?php if(auth()->user()): ?>
                            src="<?php echo e(asset('uploads/users/'.auth()->user()->image)); ?>"
                         <?php endif; ?>
                         />
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="block m-t-xs font-bold"><?php echo e(auth()->user()->name ?? ''); ?></span>
                        <span class="text-muted text-xs block"><?php echo e(auth()->user()->email ?? ''); ?><b class="caret"></b></span>
                    </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li><a class="dropdown-item" href="<?php echo e(route('profiles.index')); ?>">Profile</a></li>
                        <li>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fa fa-sign-out"></i> প্রস্থান
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
                <div class="logo-element">
                    IN+
                </div>
            </li>

            
            <li class="<?php echo e(request()->routeIs('/') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('/')); ?>"><i class="fa fa-dashboard"></i> <span class="nav-label">ড্যাশবোর্ড</span></a>
            </li>

            <li class="<?php echo e(request()->routeIs('sliders.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('sliders.index')); ?>"><i class="fa fa-image"></i> <span class="nav-label">স্লাইডার</span></a>
            </li>

            <li class="<?php echo e(request()->routeIs('upazilas.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('upazilas.index')); ?>"><i class="fa fa-universal-access"></i> <span class="nav-label">উপজেলাসমূহ</span></a>
            </li>

            <li class="<?php echo e(request()->routeIs('contacts.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('contacts.index')); ?>"><i class="fa fa-contao"></i> <span class="nav-label">যোগাযোগ</span></a>
            </li>

            <li class="<?php echo e(request()->routeIs('overseers.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('overseers.index')); ?>"><i class="fa fa-users"></i> <span class="nav-label">উপদর্শক</span></a>
            </li>

        </ul>
    </div>
</nav>
<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\layouts\elements\sidebar.blade.php ENDPATH**/ ?>