<div class="modal-header">
    <h2><?php echo e($overseer->name); ?></h2>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">

    <div style="margin-bottom: 35px" class="member">
        <div style="width: 100%; margin: 0 auto;" class="pic">
            <img src="<?php echo e(asset('uploads/overseers/'.$overseer->image)); ?>" class="img-fluid"
                 alt="<?php echo e($overseer->name); ?>">
        </div>
    </div>
    <div class="member-info">
        <div class="row">
            <div class="col-sm-12">
                <table style="color: #5c768d!important; font-size: 17px!important;">
                    <tr>
                        <td style='width: 50%' class="text-left"><strong>নাম</strong></td>
                        <td><?php echo e($overseer->name); ?></td>
                    </tr>
                    <tr>
                        <td><b>পদবী</b></td>
                        <td><?php echo e($overseer->designation); ?></td>
                    </tr>
                    <tr>
                        <td><b>মোবাইল</b></td>
                        <td><?php echo e($overseer->phone); ?></td>
                    </tr>
                    <tr>
                        <td><b>ইমেইল ঠিকানা</b></td>
                        <td><?php echo e($overseer->email); ?></td>
                    </tr>
                    <tr>
                        <td><b>বাড়ির ঠিকানা</b></td>
                        <td><?php echo e($overseer->office_address); ?></td>
                    </tr>
                    <tr>
                        <td><b>ব্যাচ নাম্বার</b></td>
                        <td><?php echo e($overseer->batch_no); ?></td>
                    </tr>
                    <tr>
                        <td><b>যোগদানের তারিখ</b></td>
                        <td><?php echo e($overseer->joining_date); ?></td>
                    </tr>
                    <tr>
                        <td><strong>ফোন (অফিস)</strong></td>
                        <td><?php echo e($overseer->office_phone); ?></td>
                    </tr>
                    <tr>
                        <td><b>অফিস ঠিকানা</b></td>
                        <td><?php echo e($overseer->office_address); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer"></div>

<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\frontend\overseers\info.blade.php ENDPATH**/ ?>