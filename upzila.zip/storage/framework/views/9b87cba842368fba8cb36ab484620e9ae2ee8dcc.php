<?php $__env->startSection('title', 'ইউনিয়ন সংসধন্ধ করুন'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.html">হোম</a>
                </li>
                <li class="breadcrumb-item">
                    <a>ইউনিয়ন</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>সংসধন্ধ করুন</strong>
                </li>
            </ol>
        </div>
    </div>

    <div class="row wrapper mt-5 border-bottom white-bg page-heading">
        <div class="col-lg-12 text-center pt-4 pb-4">
            <h2> <?php echo e($upazila->name); ?> উপজেলার <?php echo e($union->name); ?> ইউনিয়ন সংসধন্ধ করুন</h2>
        </div>
    </div>


    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox ">
                    <div class="ibox-content">
                        <div class="row">
                            <div class="col-lg-12">
                                <form enctype="multipart/form-data" role="form" method="POST" action="<?php echo e(route('upazilas.unions.update', ['upazila' => $upazila->slug, 'union' => $union->slug])); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <?php echo $__env->make('backend.unions.element', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <div>
                                        <button class="btn btn-sm btn-primary  m-t-n-xs" type="submit"><strong>সাবমিট</strong></button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\unions\edit.blade.php ENDPATH**/ ?>