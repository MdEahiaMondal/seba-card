<div class="footer">
    <div>
        <strong> &copy; Copyright <?php echo e(date('Y')); ?> <strong><span>Tax Collection Scheme Ltd. (HTCSL)</span></strong>. All rights reserved | Privacy Policy - REVISED</strong>
    </div>
</div>
<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\layouts\elements\footer.blade.php ENDPATH**/ ?>