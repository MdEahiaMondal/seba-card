<?php $__env->startSection('title', 'ইউনিয়ন সমূহ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.html">হোম</a>
                </li>
                <li class="breadcrumb-item">
                    <a>ইউনিয়ন</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>ইউনিয়ন সমূহ</strong>
                </li>
            </ol>
            <a href="<?php echo e(route('upazilas.unions.create', $upazila->slug)); ?>" class="btn btn-sm btn-primary pull-right m-t-n-md"
               type="submit"><i
                        class="fa fa-plus"></i> <strong>তৈরি করুন</strong></a>
        </div>
    </div>



    <div class="row wrapper mt-5 border-bottom white-bg page-heading">
        <div class="col-lg-12 text-center pt-4 pb-4">
             <h2> <?php echo e($upazila->name); ?> উপজেলা এর  ইউনিয়ন সমূহ</h2>
        </div>
    </div>

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox ">
                    <div class="ibox-title">
                        <h5><strong>ইউনিয়ন সমূহ</strong></h5>
                    </div>
                    <div class="ibox-content">

                        <div class="table-responsive">
                            <table class="table table-hover dataTables-example">
                                <thead>
                                <tr>
                                    <th>নং</th>
                                    <th>নাম</th>
                                    <th>ইউনিয়ন ওয়েবসাইট</th>
                                    <th>প্রক্রিয়া</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $upazila->unions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $union): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($union->name); ?></td>
                                        <td><?php echo e($union->web_link); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('upazilas.unions.edit',['upazila' => $upazila->slug, 'union' => $union->slug])); ?>" title="Edit"
                                               class="btn btn-success cus_btn">
                                                <i class="fa fa-pencil-square-o"></i> <strong>হালনাগাদ</strong>
                                            </a>

                                            <a onclick="deleteRow(<?php echo e($union->id); ?>)" href="JavaScript:void(0)"
                                               title="Delete" class="btn btn-danger cus_btn">
                                                <i class="fa fa-trash"></i> <strong>বাদ দিন</strong>
                                            </a>
                                            <form id="row-delete-form<?php echo e($union->id); ?>" method="POST"
                                                  action="<?php echo e(route('upazilas.unions.destroy',['upazila' => $upazila->slug, 'union' => $union->slug])); ?>"
                                                  style="display: none">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\unions\index.blade.php ENDPATH**/ ?>