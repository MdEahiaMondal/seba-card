<div class="form-group">
    <label>শিরোনাম</label>
    <input type="text" name="title" value="<?php echo e(isset($slider)?$slider->title:old('title')); ?>" placeholder="শিরোনাম" class="form-control">
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label>ছবি</label>
    <input type="file" onchange="imagePreview(event)" name="photo" placeholder="ছবি" class="form-control hjhjghjghj">
    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label>স্ট্যাটাস</label>
    <input name="status" <?php echo e(isset($slider) && $slider->status ? 'checked' : ''); ?> value="1" type="checkbox" class="i-checks">
</div>
<div>
    <button class="btn btn-sm btn-primary float-right m-t-n-xs" type="submit"><strong>সাবমিট</strong></button>
</div><?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\sliders\element.blade.php ENDPATH**/ ?>