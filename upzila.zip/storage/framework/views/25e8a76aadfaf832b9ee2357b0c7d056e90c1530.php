
<div class="appendForm">
    <div class="row">
        <div class="col-md-5">
            <div class="form-group">
                <label for="নাম">নাম</label>
                <input type="text"
                       id="নাম"
                       name="name[]"
                       value="<?php echo e(isset($union)?$union->name:old('name[]')); ?>"
                       class="form-control">
                <?php $__errorArgs = ['name.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="form-group">
                <label for="web_link">ওয়েব লিংক</label>
                <input type="text"
                       id="web_link"
                       name="web_link[]"
                       value="<?php echo e(isset($union)?$union->web_link:old('web_link[]')); ?>"
                       class="form-control">
                <?php $__errorArgs = ['web_link.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <?php if(empty($union)): ?>
            <div class="col-md-2 offset-sm-10 offset-md-0">
                <div class="form-group">
                    <button onclick="appendNerForm(event)" style="margin-top: 28px;height: 35px;"
                            class="btn btn-primary"
                    ><i class="fa fa-plus"></i>
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>










<?php $__env->startPush('script'); ?>
    <script>

        var html = `<div class="row">
    <div class="col-md-5">
        <div class="form-group">
            <label for="নাম">নাম</label>
            <input type="text"
                   id="নাম"
                   name="name[]"
                   value="<?php echo e(isset($union)?$union->name:old('name[]')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['name.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-5">
        <div class="form-group">
            <label for="web_link">ওয়েব লিংক</label>
            <input type="text"
                   id="web_link"
                   name="web_link[]"
                   value="<?php echo e(isset($union)?$union->web_link:old('web_link[]')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['web_link.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-2 offset-sm-10 offset-md-0">
        <div class="form-group">
            <button style="margin-top: 28px;height: 35px;"
                    class="btn btn-danger removeItem"
            ><i class="fa fa-trash"></i>
            </button>
        </div>
    </div>
</div>`

        function appendNerForm(event) {
            event.preventDefault()
            $('.appendForm').prepend(html)
        }
        function removeItem() {
            event.preventDefault()
            $(this).parents('.row').remove();
        }


        $(document).on("click", ".removeItem", function(event) {
            event.preventDefault()
            $(this).closest('.row').remove();
        });

        $(document).ready(function () {



        })
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\unions\element.blade.php ENDPATH**/ ?>