
<?php $__env->startSection('title', 'প্রোফাইল'); ?>


<?php $__env->startSection('content'); ?>

    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-lg-12">
            <h2>প্রোফাইল</h2>
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.html">ড্যাশবোর্ড</a>
                </li>
                <li class="breadcrumb-item active">
                    <strong>প্রোফাইল</strong>
                </li>
            </ol>
        </div>
        <div class="col-lg-2">

        </div>
    </div>
    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="wrapper wrapper-content">
            <div class="row animated fadeInRight">
                <div class="col-md-4">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>প্রোফাইল বিশদ</h5>
                        </div>
                        <div>
                            <div class="ibox-content no-padding border-left-right">
                                <img alt="image" class="img-fluid"
                                     <?php if(auth()->user()): ?>
                                        src="<?php echo e(asset('uploads/users/'.auth()->user()->image)); ?>"
                                     <?php endif; ?>>
                            </div>
                            <div class="ibox-content প্রোফাইল-content">
                                <h4><strong><?php echo e(auth()->user()->name ?? ''); ?></strong></h4>
                                <p><i class="fa fa-google-plus"> </i> <?php echo e(auth()->user()->email ?? ''); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="ibox ">
                        <div class="ibox-title">
                            <h5>প্রোফাইল ক্রিয়াকলাপ</h5>
                        </div>
                        <div class="ibox-content">
                            <div>
                                <div class="feed-activity-list">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">প্রোফাইল</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="প্রোফাইল-tab" data-toggle="tab" href="#প্রোফাইল" role="tab" aria-controls="প্রোফাইল" aria-selected="false">পাসওয়ার্ড</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active mt-5" id="home" role="tabpanel" aria-labelledby="home-tab">
                                            <form method="post" action="<?php echo e(route('profiles.update', auth()->user()->id ?? '')); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="form-group">
                                                    <label for="name">নাম</label>
                                                    <input type="text" value="<?php echo e(auth()->user()->name ?? ''); ?>" name="name" class="form-control" id="name">
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <input type="hidden" name="info" value="info">
                                                <div class="form-group">
                                                    <label for="exampleInputEmail1">ইমেল ঠিকানা</label>
                                                    <input type="email" value="<?php echo e(auth()->user()->email ?? ''); ?>" name="email" class="form-control" id="exampleInputEmail1">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="form-group">
                                                    <label>ছবি</label>
                                                    <div class="custom-file">
                                                        <input id="logo"
                                                               type="file"
                                                               name="photo"
                                                               class="custom-file-input">
                                                        <label for="logo" class="custom-file-label">Choose file...</label>
                                                    </div>
                                                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <button type="submit" class="btn btn-primary">হালনাগাদ</button>
                                            </form>
                                        </div>
                                        <div class="tab-pane fade mt-5" id="প্রোফাইল" role="tabpanel" aria-labelledby="প্রোফাইল-tab">
                                            <form method="post" action="<?php echo e(route('profiles.update', auth()->user()->id ?? '')); ?>" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="form-group">
                                                    <label for="current_password">বর্তমান পাসওয়ার্ড</label>
                                                    <input type="password" name="current_password" class="form-control" id="current_password">
                                                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="password">নতুন পাসওয়ার্ড</label>
                                                    <input type="password" name="password" class="form-control" id="password">
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="form-group">
                                                    <label for="password_confirmation">পাসওয়ার্ড নিশ্চিত করুন</label>
                                                    <input type="password" name="password_confirmation" class="form-control" id="password_confirmation">
                                                </div>
                                                <button type="submit" class="btn btn-primary">হালনাগাদ</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\profile\index.blade.php ENDPATH**/ ?>