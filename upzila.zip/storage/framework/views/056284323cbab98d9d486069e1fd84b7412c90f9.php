
<?php $__env->startSection('title', 'আপনার ইমেল ঠিকানা যাচাই করুন'); ?>
<?php $__env->startSection('from'); ?>

    <div class="ibox-content">
        <h2 class="text-center font-bold p-4">Verify Your Email Address</h2>
        <?php if(session('resent')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

            </div>
        <?php endif; ?>

        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

        <?php echo e(__('If you did not receive the email')); ?>,
        <form class="m-t" role="form" method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary block full-width m-b font-bold">click here to request another</button>
        </form>
    </div>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\auth\verify.blade.php ENDPATH**/ ?>