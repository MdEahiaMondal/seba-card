<div class="form-group">
    <label for="নাম">নাম</label>
    <input type="text"
           id="নাম"
           name="name"
           value="<?php echo e(isset($upazila)?$upazila->name:old('name')); ?>"
           class="form-control">
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-group row">
    <div class="col-lg-offset-2 col-lg-10">
        <div class="i-checks">
            <label>
                <i></i> স্ট্যাটাস
                <input type="checkbox" name="status" id="স্ট্যাটাস"
                       <?php echo e(isset($upazila) && $upazila->status ? 'checked' : ''); ?> value="1">
            </label>
        </div>
    </div>
</div>
<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\upazilas\element.blade.php ENDPATH**/ ?>