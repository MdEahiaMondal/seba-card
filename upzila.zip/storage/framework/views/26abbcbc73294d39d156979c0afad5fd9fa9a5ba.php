<div class="row">

    <div class="col-md-6">
        <div class="form-group">
            <label for="নাম">নাম</label>
            <input type="text"
                   id="নাম"
                   name="name"
                   value="<?php echo e(isset($overseer)?$overseer->name:old('name')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group">
            <label for="ইমেল">ইমেল</label>
            <input type="email"
                   id="ইমেল"
                   name="email"
                   value="<?php echo e(isset($overseer)?$overseer->email:old('email')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="ফোন">ফোন</label>
            <input type="text"
                   id="ফোন"
                   name="phone"
                   value="<?php echo e(isset($overseer)?$overseer->phone:old('phone')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="home_address">বাসার ঠিকানা</label>
            <input type="text"
                   id="home_address"
                   name="home_address"
                   value="<?php echo e(isset($overseer)?$overseer->home_address:old('home_address')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['home_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label>ছবি</label>
            <div class="custom-file">
                <input id="logo"
                       type="file"
                       onchange="imagePreview(event)"
                       name="photo"
                       class="custom-file-input">
                <label for="logo" class="custom-file-label">Choose file...</label>
            </div>
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="উপাধি">উপাধি</label>
            <input type="text"
                   id="উপাধি"
                   name="designation"
                   value="<?php echo e(isset($overseer)?$overseer->designation:old('designation')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="batch_no">ব্যাচ নাম্বার</label>
            <input type="text"
                   id="batch_no"
                   name="batch_no"
                   value="<?php echo e(isset($overseer)?$overseer->batch_no:old('batch_no')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['batch_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="joining_date">যোগদান তারিখ</label>
            <input type="date"
                   id="joining_date"
                   name="joining_date"
                   value="<?php echo e(isset($overseer)?$overseer->joining_date:old('joining_date')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['joining_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="office_phone">অফিসের ফোন</label>
            <input type="text"
                   id="office_phone"
                   name="office_phone"
                   value="<?php echo e(isset($overseer)?$overseer->office_phone:old('office_phone')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['office_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="office_address">অফিসের ঠিকানা</label>
            <input type="text"
                   id="office_address"
                   name="office_address"
                   value="<?php echo e(isset($overseer)?$overseer->office_address:old('office_address')); ?>"
                   class="form-control">
            <?php $__errorArgs = ['office_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group row">
            <div class="col-lg-offset-2 col-lg-10">
                <div class="i-checks">
                    <label>
                        <i></i> স্ট্যাটাস
                        <input type="checkbox" name="status" id="স্ট্যাটাস" <?php echo e(isset($overseer) && $overseer->status ? 'checked' : ''); ?> value="1">
                    </label>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group row">
            <label class="col-sm-2 col-form-label">লিঙ্গ</label>
            <div class="col-sm-10">
               <span class="i-checks"><label> <input type="radio" <?php echo e(isset($overseer) && $overseer->gender == 'পুরুষ' ? 'checked' : ''); ?> value="পুরুষ" name="gender"> <i></i> পুরুষ</label></span>
                <span class="i-checks"><label> <input type="radio" <?php echo e(isset($overseer) && $overseer->gender == 'মহিলা' ? 'checked' : ''); ?> value="মহিলা" name="gender"> <i></i> মহিলা </label></span>
            </div>
        </div>
    </div>

</div>




























<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\overseers\element.blade.php ENDPATH**/ ?>