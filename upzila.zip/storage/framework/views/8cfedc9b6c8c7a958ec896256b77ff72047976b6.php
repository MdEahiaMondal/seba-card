<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content overseerDetails">
            
        </div>
    </div>
</div>
<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views/modal.blade.php ENDPATH**/ ?>