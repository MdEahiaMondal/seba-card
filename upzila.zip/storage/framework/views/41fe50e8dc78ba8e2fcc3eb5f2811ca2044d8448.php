<div class="form-group">
    <label for="our_address">আমাদের ঠিকানা</label>
    <input type="text" id="our_address" name="our_address" value="<?php echo e(isset($contact)?$contact->our_address:old('our_address')); ?>" class="form-control">
    <?php $__errorArgs = ['our_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="ফোন">ফোন</label>
    <input type="text" id="ফোন" name="phone" value="<?php echo e(isset($contact)?$contact->phone:old('phone')); ?>"  class="form-control">
    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="ইমেল">ইমেল</label>
    <input type="email" id="ইমেল" name="email" value="<?php echo e(isset($contact)?$contact->email:old('email')); ?>"  class="form-control">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="ওয়েব">ওয়েব</label>
    <input type="text" id="ওয়েব" name="web" value="<?php echo e(isset($contact)?$contact->web:old('web')); ?>"  class="form-control">
    <?php $__errorArgs = ['web'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="ফ্যাক্স">ফ্যাক্স</label>
    <input type="text" id="ফ্যাক্স" name="fax" value="<?php echo e(isset($contact)?$contact->fax:old('fax')); ?>"  class="form-control">
    <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="help-block m-b-none text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="স্ট্যাটাস">স্ট্যাটাস</label>
    <input name="status" id="স্ট্যাটাস" <?php echo e(isset($contact) && $contact->status ? 'checked' : ''); ?> value="1" type="checkbox" class="i-checks">
</div>

<?php /**PATH F:\xamp-7.3.10\htdocs\job\upzila\resources\views\backend\contacts\element.blade.php ENDPATH**/ ?>